import numpy as np
import librosa
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.stats import entropy

def analyze_phase(audio_file, segment_length=2048):
    try:
        # Doc file am thanh
        y, sr = librosa.load(audio_file, sr=None)
        
        # Chia tin hieu thanh cac doan ngan
        n_segments = len(y) // segment_length
        phase_variances = []
        phase_entropies = []
        
        for i in range(n_segments):
            segment = y[i * segment_length:(i + 1) * segment_length]
            
            # Tinh FFT va lay pho pha
            fft_result = np.fft.fft(segment)
            phase = np.angle(fft_result)
            
            # Tinh do bien thien cua pha
            phase_variance = np.var(phase)
            phase_variances.append(phase_variance)
            
            # Tinh entropy cua pha
            hist, _ = np.histogram(phase, bins=50, density=True)
            phase_entropy = entropy(hist)
            phase_entropies.append(phase_entropy)
        
        # Phan tich thong ke
        mean_variance = np.mean(phase_variances)
        std_variance = np.std(phase_variances)
        mean_entropy = np.mean(phase_entropies)
        std_entropy = np.std(phase_entropies)
        
        # In cac gia tri thong ke
        print(f"Do bien thien pha trung binh: {mean_variance:.6f}")
        print(f"Do lech chuan cua do bien thien pha: {std_variance:.6f}")
        print(f"Entropy pha trung binh: {mean_entropy:.6f}")
        print(f"Do lech chuan cua entropy pha: {std_entropy:.6f}")
        
        # Phat hien doan bat thuong
        threshold = mean_variance + 2 * std_variance
        anomalies = [var for var in phase_variances if var > threshold]
        
        # Phan tich tu tuong quan de tim mau lap lai
        autocorr = np.correlate(phase_variances - np.mean(phase_variances), 
                               phase_variances - np.mean(phase_variances), mode='full')
        autocorr = autocorr[len(autocorr)//2:]  # Lay nua duong
        peaks, _ = find_peaks(autocorr, height=np.max(autocorr) * 0.3)
        
        # Ve bieu do
        plt.figure(figsize=(12, 8))
        
        # Bieu do do bien thien pha
        plt.subplot(3, 1, 1)
        plt.plot(phase_variances, label="Do bien thien pha")
        plt.axhline(y=threshold, color='r', linestyle='--', label="Nguong")
        plt.title("Do Bien Thien Pha Theo Cac Doan")
        plt.xlabel("Chi so doan")
        plt.ylabel("Do bien thien pha")
        plt.legend()
        
        # Bieu do entropy pha
        plt.subplot(3, 1, 2)
        plt.plot(phase_entropies, label="Entropy pha")
        plt.title("Entropy Pha Theo Cac Doan")
        plt.xlabel("Chi so doan")
        plt.ylabel("Entropy pha")
        plt.legend()
        
        # Bieu do tu tuong quan
        plt.subplot(3, 1, 3)
        plt.plot(autocorr, label="Tu tuong quan")
        plt.plot(peaks, autocorr[peaks], "x", label="Dinh")
        plt.title("Tu Tuong Quan cua Do Bien Thien Pha")
        plt.xlabel("Do tre")
        plt.ylabel("Tu tuong quan")
        plt.legend()
        
        plt.tight_layout()
        # Luu bieu do thanh file
        plt.savefig("phase_analysis.png")
        plt.close()  # Dong figure de tranh chiem bo nho
        
        # In cac thong bao nghi ngo
        print("\nPhan Tich Cac Diem Nghi Ngo:")
        if len(anomalies) > 0:
            print(f"- Phat hien {len(anomalies)} doan co do bien thien pha bat thuong (vuot nguong {threshold:.6f}).")
        else:
            print("- Khong phat hien doan nao co do bien thien pha bat thuong.")
        
        if len(peaks) > 0:
            print(f"- Phat hien {len(peaks)} dinh trong tu tuong quan, cho thay co the co mau lap lai.")
        else:
            print("- Khong phat hien mau lap lai dang ke trong do bien thien pha.")
        
        if mean_entropy < 3.0 or std_entropy < 0.2:
            print(f"- Entropy pha dang ngo: Trung binh ({mean_entropy:.6f}) hoac do lech chuan ({std_entropy:.6f}) thap, co the cho thay tin giau.")
        else:
            print("- Entropy pha co ve binh thuong.")
        
        # Dua ra ket luan cuoi cung
        print("\nKet Luan Cuoi Cung:")
        suspicious_points = 0
        if len(anomalies) > 5:
            suspicious_points += 1
            print("- So luong doan bat thuong cao, cho thay co kha nang chua tin giau.")
        if len(peaks) > 0:
            suspicious_points += 1
            print("- Co mau lap lai trong do bien thien pha, cho thay co kha nang chua tin giau.")
        if mean_entropy < 3.0 or std_entropy < 0.2:
            suspicious_points += 1
            print("- Entropy pha thap hoac on dinh bat thuong, cho thay co kha nang chua tin giau.")
        
        if suspicious_points >= 2:
            print(">>> File RAT CO KHA NANG chua tin giau (co the su dung phuong phap phase coding).")
        elif suspicious_points == 1:
            print(">>> File NGHI NGO chua tin giau nhung chua ket luan duoc. Can phan tich them.")
        else:
            print(">>> File KHONG CO KHA NANG chua tin giau.")
        
    except Exception as e:
        print(f"Da xay ra loi: {str(e)}")

# Su dung
audio_file = r"plain.wav"  # Su dung raw string de tranh loi escape
analyze_phase(audio_file)
